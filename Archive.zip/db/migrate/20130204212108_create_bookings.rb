class CreateBookings < ActiveRecord::Migration
  def change
    create_table :bookings do |t|
      t.date :booking_date
      t.integer :no_of_seats
      t.time :time

      t.timestamps
    end
  end
end
