# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Mytwitter::Application.config.secret_token = '288bc7c108cb00362c3685a091573da9dfaa40248242c2aa2275b3254fd8bd2690fc45a063cbd6b64e0fc1ed5ac1dbf8978d8850ab910b4c4d6c692a46805af7'
