class RestaurantsController < ApplicationController
  
  respond_to :json

  def show
    @restaurant = Restaurant.find(params[:id])

    respond_to do |format|
           format.html # show.html.erb
           format.json { render :json => @restaurant}
  end

end

def index
  @restaurant = Restaurant.all 

  respond_to do |format|
           
           format.json { render :json => @restaurant, only: [:name, :address, :phone_no, :email, :picture, :description, :location, :food_type, :price_range, :rating, :veg_friendly, :coeliac_friendly, :vegan_friendly]}
  end

  end





  def new
    @restaurant = Restaurant.new
  end

  def create
    @restaurant = Restaurant.new(params[:restaurant])
    if @restaurant.save
      flash[:success] = "Welcome to the LookBookEat!" 
      redirect_to @restaurant
    else
      render 'new'
    end
  end
end