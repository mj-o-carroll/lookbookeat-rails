class Booking < ActiveRecord::Base
  attr_accessible :booking_date, :no_of_seats, :time

  belongs_to :restaurant
  belongs_to :user

end
