class Advertisment < ActiveRecord::Base
  attr_accessible :ad_content, :ad_duration, :ad_start_date, :cost, :date_payment

  belongs_to :restaurant
end
