class SpecialOffer < ActiveRecord::Base
  attr_accessible :so_content, :so_description, :so_finish, :so_start, :so_title

  belongs_to :restaurant
  
end
