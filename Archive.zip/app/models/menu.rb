class Menu < ActiveRecord::Base
  attr_accessible :content, :menu_type, :title

  belongs_to :restaurant
  
end
