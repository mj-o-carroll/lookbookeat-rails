class Comments < ActiveRecord::Base
  attr_accessible :content, :date

  belongs_to :restaurant
  belongs_to :user
end
